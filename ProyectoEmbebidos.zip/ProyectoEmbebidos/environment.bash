export RIOTBASE=$HOME/riot-sdk
# export PATH=$PATH:$HOME/.local/bin/
export PATH=$PATH:$HOME/.espressif/tools/xtensa-esp32-elf/esp-2021r2-patch3-8.4.0/xtensa-esp32-elf/bin/

# . $RIOTBASE/dist/tools/esptools/export.sh esp32 >> log
